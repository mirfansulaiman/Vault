# as mentioned before there is much similarity beetwin Smb and NBt so looking for similar problems inside the drivers is a great motive.

# sleepya's (Great!) work on the Nsa-familly exploits:
Re: <html><a href="http://blogs.360.cn/360safe/2017/04/17/nsa-eternalblue-smb/">nsa-eternalblue-smb</a></html> <br>
<html><a href="https://www.exploit-db.com/exploits/42031/">exploit</a></html> <br> 
Re: <html><a href="http://blogs.360.cn/360safe/author/progmboy/">eternalromance</a></html> <br>
<html><a href="https://www.exploit-db.com/exploits/42315/">exploit</a></html><br>
