
<script>
$(function(){
    $('a').each(function() {
	$(this).attr('href', 'https://botgoat.com/anja/get?url=' + this.href);
    });
});
</script>


