# MultiThreaded java load balancer
	given a single Threaded program
	the load balancer will activate this
	program assign that Thread an 
	address, a speciel security string
	and redirect the user to that location.
	you will need a "killer" script thou.. (to kill the threads)...
	
