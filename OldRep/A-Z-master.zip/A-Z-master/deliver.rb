#!/usr/bin/env ruby

require 'rubygems'
require "webrick"
require 'open-uri'
require 'net/http'
require 'webrick/https' 

host, port, = '', 8888
$content = File.read 'index.html'

module OpenURI
  class << self
    def redirectable?(uri1, uri2)
      a, b = uri1.scheme.downcase, uri2.scheme.downcase
      a == b || (a == 'http' && b == 'https')
      a == b || (a == 'https' && b == 'http')
    end
  end
end

server = WEBrick::HTTPServer.new :Port => port,
                                 :Host => host


trap("INT") {
    server.shutdown
}

server.mount_proc '/7zip.exe' do |req, res|
      res.status = 200
      res.content_type = "Content-Type: application/octet-stream\n\rContent-Disposition: 7zip.exe\n\r"
      cont = File.read("/...../7zip.exe")
      res.body = cont
end

server.mount_proc '/' do |req, res|
    res.status = 200
    res.content_type = "text/html"
    res.body = $content
end

server.start

