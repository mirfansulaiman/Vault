# exploiting multiple Vulnerabilities to bypassUac & edge virus check to install a BackDoor On a target machine

# introduction
  this tutorial utilize multiple aspect and vulnrabilites found at the latest windows installation,<br>
  and microsoft edge. we will go throw a complete guide on how to install a backdoor on any windows machine,<br>
  without the user consent, and the different opportunities to deliver the payload to our target machine.<br>
  <br>
  1) delivering the payload.<br>
  2) exploiting edge security scan.<br>
  3) bypassing uac to get access to the machine registry without the user consent.<br>
  <br>
  
# Tech
  
  1 -> Delivery: There are multiple ways to deliver the payload to the target machine,<br>
  in this tutorial we will use standard phishing, all though we can just post this download page as a<br>
  legitimate url and wait for targets.<br>
  another method is to intercept traffic MITM style <html><a href="https://www.youtube.com/watch?v=0QT4YJn7oVI">this may be interesting.</a></html><br> but at my opinion the technolegy used by that reference is to heavy, and this tutorial much<br>
  simplify the delivery process, simply by using Rails/Webrick, that has a proxy built-in <br>
  (that is also utilized by <html><a href="https://www.bettercap.org/">bettercap</a></html>).<br>
  delivery can also be achieved by exploiting an smb share (cuz the payload do not prompt the user at any case).<br>
  or alternatively delivering the payload by mail, or a buffer over flow exploit, or evan simpler, send The user a link..
   
  Backend:<br>
    Run delivery.rb on your machine, to serve the fake download page & to serve the .exe as a payload.<br>
  Frontend:<br>
    Edit the html page as follow:<br>
    
# 1
 ![](pic/Edit1.png)
# 2
 ![](pic/Edit2.png)
    <br>
    at this stage your all set to serve the payload.<br>
    note that any one connected to your site will provide you the ip address to later connect to the machine.<br>
![](pic/Conn.png)

2) PayLoad..<br>
  our payload exploits two Vulnerabilities at the target machine.<br>
  [I] edge security scan<br>
  [II] the uac machanisem<br>
  
  edge security scan like many anti-virus use The <html><a href="https://www.techopedia.com/definition/4080/reputation-based-security">Reputation-Based Security</a></html> in order to scan your file.<br>
  in addition most modern anti-virus use the <html><a href="https://blogs.cisco.com/security/malware_validation_techniques">entropy measure</a></html> to diagnose The file scanned. as we found, any unsigned file will automaticlly pass the reputation mechanisem (for not alerting the user,
  if you will open norton anti-virus he will tell you that this file has not been used many times, and that it cant proved
  data on the file tested, but this do the trick for us)<br>
  we target the second parameter: The entropy & the file binary properties, by simply adding junk code at our .NET payload.<br>
  Take any known malware source, and compile your own copy, but add junk methods, that are never called,<br>
  for example, getCurrentTime();, method. or addTwoIntegers();, that way you change the binary properties, and you<br>
  can even call those methods, to make reverse analysis harder.
  any way, using those two method's completely castrate's the edge chack, and this is good enough for us.<br>
  
3) installation. as any one knows, to operate regedit, or to make any changes to the current installation (by the registry)
one needs elevation.<br>
but, the windows default configuration is to allow one to edit the CURRENT_USER sub section, without any uac.
we exploit that, to install our programm. this has some disadvantage's, meaning that our BackDoor will only be installed and persistent on the current user logon.<br>

This works really straight forward, as the user clicks on the .exe the exe is granted the user token, so the programm has<br>
all access to the current user settings, including firewall rules, networking, programm installation, task configuration<br>
and logon scripts. as the user account that executed the payload. one can claim "hey but you do not have NT authority you only have resticted access to the machine"<br>
That is indeed correct, but ill reffer the reader to <html><a href="https://twitter.com/Yena0xC5/status/878616204931457024">By Passing Uac</a></html> that can be implemented throw our interactive backdoor later on. or alternatively to the "user guide" for bypassing the uac component:<html><a href="https://github.com/hfiref0x/UACME">UACME</a></html>.<br>

# well.. all that is left is to view the PoC:

![poc](pic/poc.gif)

![](pic/pocR.png)

# addendum
  at this point you are the user, without any user interaction, or approval. note that our 7zip, was deleted by the user,<br>
  but it do not contain the backdoor itself so we are all good, for security reasons i do not upload the payload, or state<br>
  the settings changes that the payload executes...
  
# microsoft point of view
![](pic/mic.png)
  

