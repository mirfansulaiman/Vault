#pragma once
#include "stdafx.h"

vector<string> ReSplit(
	const string & s,
	string rgx_str
);

vector<string> SplitEntries(
	string Ent
);

unsigned int FileRead(
	istream & is,
	vector <char> & buff
);

LPWSTR ConvertToLPWSTR(
	const string& s
);

void Wait(
);

BOOL SetPrivilege(
	HANDLE hToken,
	LPCTSTR lpszPrivilege,
	BOOL bEnablePrivilege
);

VOID EnumStoreEntries(
	string & Inf,
	lMi &lmi,
	vector<St> &Sl
);

int TikCount(
	vector<string> &StEnt
);