
#include "stdafx.h"
#include "utls.h"

const char* Strt = "C:\\Sukhoi\\bin\\Strtr.exe";

string GetOutPutAndDelete(
	const char * fs,
	ifstream & ifs,
	string & s,
	lMi &lmi,
	vector<St> &Sl
	) 
{
	const unsigned int BUFSIZE = 1500 * 1024; 
	std::vector <char> buffer(BUFSIZE);

	while (unsigned int n = FileRead(ifs, buffer)) {
		s.append(&buffer[0], n);
	}
	int Tk = remove(fs);
	EnumStoreEntries(s, lmi, Sl);
	return s;
}

VOID ExecuteAndEnumerate(
	Exopt &Gp,
	lMi &lmi,
	vector<St> &Sl,
	int Ck
	)
{
	HANDLE hProc = ShellExecute(
		Gp.hwnd,
		Gp.lpOperation,
		Gp.lpFile,
		Gp.lpParameters,
		Gp.lpDirectory,
		Gp.nShowCmd
	);
	if( Ck== 0 ){
	CloseHandle(hProc);
	string g = "";
	ifstream ifs(Gp.s);
	string Cu = GetOutPutAndDelete(Gp.fs, ifs, g, lmi, Sl);
	}
}

Exopt Setter(
	string Opt,
	string ident,
	string newVal
	) 
{
	Exopt Ap;

	if (Opt == "enum") {
		Ap.hwnd = (HWND)GetCurrentProcess();
		Ap.lpOperation = L"runas";
		Ap.lpFile = L"C:\\Windows\\System32\\cmd.exe";
		Ap.lpParameters = L"/c C:\\Windows\\Sysnative\\bcdedit > C:\\Sukhoi\\Debug\\inf.txt";
		Ap.lpDirectory = NULL;
		Ap.nShowCmd = 0;
		Ap.fs = "C:\\Sukhoi\\Debug\\inf.txt";
		Ap.s = "C:\\Sukhoi\\Debug\\inf.txt";
	}
	else if (Opt == "delete") {
		Ap.hwnd = (HWND)GetCurrentProcess();
		Ap.lpOperation = L"runas";
		Ap.lpFile = L"C:\\Windows\\System32\\cmd.exe";
		string execv = "/c C:\\Windows\\Sysnative\\bcdedit.exe /delete ";
		execv += ident; execv += " /cleanup";
		//execv += " /remove";
		//cout << execv;
		Ap.lpParameters = ConvertToLPWSTR(execv);
		Ap.lpDirectory = NULL;
		Ap.nShowCmd = 0;   //SW_SHOW
		Ap.fs = "C:\\Sukhoi\\Debug\\inf.txt";
		Ap.s = "C:\\Sukhoi\\Debug\\inf.txt";
	} 
	else if (Opt == "set") {
		Ap.hwnd = (HWND)GetCurrentProcess();
		Ap.lpOperation = L"runas";
		Ap.lpFile = L"C:\\Windows\\System32\\cmd.exe";
		string execv = "/c C:\\Windows\\Sysnative\\bcdedit.exe /set ";
		execv += ident; execv += " "; execv += newVal;
		//execv += " /remove";
		//cout << execv;
		Ap.lpParameters = ConvertToLPWSTR(execv);
		Ap.lpDirectory = NULL;
		Ap.nShowCmd = 0;   //
		Ap.fs = "C:\\Sukhoi\\Debug\\inf.txt";
		Ap.s = "C:\\Sukhoi\\Debug\\inf.txt";
	} 
	else if (Opt == "debug") {
		Ap.hwnd = (HWND)GetCurrentProcess();
		Ap.lpOperation = L"runas";
		Ap.lpFile = L"C:\\Windows\\System32\\cmd.exe";
		string execv = "/c C:\\Windows\\Sysnative\\bcdedit.exe /debug ";
		execv += ident; execv += " "; execv += newVal;
		//execv += " /remove";
		//cout << execv;
		Ap.lpParameters = ConvertToLPWSTR(execv);
		Ap.lpDirectory = NULL;
		Ap.nShowCmd = 0;   //
		Ap.fs = "C:\\Sukhoi\\Debug\\inf.txt";
		Ap.s = "C:\\Sukhoi\\Debug\\inf.txt";
	} 
	else if (Opt == "create") {
		Ap.hwnd = (HWND)GetCurrentProcess();
		Ap.lpOperation = L"runas";
		Ap.lpFile = L"C:\\Windows\\System32\\cmd.exe";
		string execv = "/c C:\\Windows\\Sysnative\\bcdedit.exe /copy {current} /d ";
		//execv += ident;
		//execv += " "; 
		execv += newVal;
		//execv += " /remove";
		//cout << execv;
		Ap.lpParameters = ConvertToLPWSTR(execv);
		Ap.lpDirectory = NULL;
		Ap.nShowCmd = 0;   //
		Ap.fs = "C:\\Sukhoi\\Debug\\inf.txt";
		Ap.s = "C:\\Sukhoi\\Debug\\inf.txt";
	} //bcdedit /copy {current} /d "DebugEntry"
	return Ap;
}

void main(
	int argc,
	char* argv[]
	)
{
	system( Strt );
	Wait();
	Exopt Opt = Setter("enum","","");
	bool Aut = SetPrivilege(GetCurrentProcess(), SE_TCB_NAME, true);
	lMi lmi;
	vector<St> Sl;
	ExecuteAndEnumerate(Opt, lmi, Sl, 0);
	//Exopt Sec = Setter("delete", Sl[0],"");
	//ExecuteAndEnumerate(Sec,lmi,Sl, 1);
	//Exopt Thr = Setter("set", "testsigning", "No");
	//Exopt Frth = Setter("debug","{current}","on");
	Exopt fve = Setter("create", "", "Suko");
	ExecuteAndEnumerate(fve, lmi, Sl, 1);
	//ExecuteAndEnumerate(Frth, lmi, Sl, 1);
}

