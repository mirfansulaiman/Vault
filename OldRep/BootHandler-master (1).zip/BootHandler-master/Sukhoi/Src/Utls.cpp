#include "stdafx.h"
#include "Utls.h"

vector<string> ReSplit(
	const string & s,
	string rgx_str
)
{
	vector<string> elems;
	regex rgx(rgx_str);
	sregex_token_iterator iter(s.begin(), s.end(), rgx, -1);
	sregex_token_iterator end;
	while (iter != end) {
		elems.push_back(*iter);
		++iter;
	}
	return elems;
}

vector<string> SplitEntries(
	string Ent
)
{
	string delim = "\\n";
	vector<string> Arr = ReSplit(Ent, delim);
	return Arr;
}

unsigned int FileRead(
	istream & is,
	vector <char> & buff
)
{
	is.read(&buff[0], buff.size());
	return is.gcount();
}

LPWSTR ConvertToLPWSTR(
	const std::string& s
)
{
	LPWSTR ws = new wchar_t[s.size() + 1];
	copy(s.begin(), s.end(), ws);
	ws[s.size()] = 0;
	return ws;
}

VOID Wait(
)
{
	for (int i = 0; i < 100000000; i++) {}
}

BOOL SetPrivilege(
	HANDLE hToken,
	LPCTSTR lpszPrivilege,
	BOOL bEnablePrivilege
)
{
	TOKEN_PRIVILEGES tp;
	LUID luid;

	if (!OpenProcessToken(GetCurrentProcess(),
		TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
		return false;

	LookupPrivilegeValue(NULL, SE_SECURITY_NAME,
		&tp.Privileges[0].Luid);

	tp.PrivilegeCount = 1;
	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	try {
		AdjustTokenPrivileges(hToken, FALSE, &tp, 0,
			(PTOKEN_PRIVILEGES)NULL, 0);
		return true;
	}
	catch (const std::exception& e) {
		cout << e.what();
	}

	if (!LookupPrivilegeValue(
		NULL,
		lpszPrivilege,
		&luid))
	{
		return FALSE;
	}

	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	if (bEnablePrivilege)
		tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	else
		tp.Privileges[0].Attributes = 0;
	if (!AdjustTokenPrivileges(
		hToken,
		FALSE,
		&tp,
		sizeof(TOKEN_PRIVILEGES),
		(PTOKEN_PRIVILEGES)NULL,
		(PDWORD)NULL))
	{
		return FALSE;
	}

	if (GetLastError() == ERROR_NOT_ALL_ASSIGNED)

	{
		return FALSE;
	}

	return TRUE;
}

int TikCount(
	vector<string> &StEnt
) {
	int count = 0;
	for (int k = 0; k < StEnt.size(); k++) {
		if (StEnt[k].find("-------------------") != string::npos) {
			count++;
		}
	}
	return count;
}

VOID EnumStoreEntries(
	string & Inf,
	lMi &lmi,
	vector<St> &Sl
	)
{
	int x = 0;
	vector<string> StEnt = SplitEntries(Inf);
	int TikCount_ = TikCount(StEnt) - 1;
	Sl.resize(TikCount_);
	int senity = 0;
	for (int k = 0; k < StEnt.size(); k++) {
		if (x == TikCount_) {
			break;
		}
		if (StEnt[k].find("identifier") != string::npos && x == 0) {
			lmi.ident = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("device") != string::npos && x == 0) {
			lmi.device = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("locale") != string::npos && x == 0) {
			lmi.locale = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("inherit") != string::npos && x == 0) {
			lmi.inherit = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("nointegritychecks") != string::npos && x == 0) {
			lmi.noIntegrityChacks = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("default") != string::npos && x == 0) {
			lmi.def = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("resumeobject") != string::npos && x == 0) {
			lmi.resObj = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("toolsdisplayorder") != string::npos && x == 0) {
			lmi.toolsDisplay = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("timeout") != string::npos && x == 0) {
			lmi.timeout = ReSplit(StEnt[k], "\\s+")[1];
			x++;
		}
		else if (StEnt[k].find("identifier") != string::npos && x != 0) {
			Sl[x-1].ident = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("device") != string::npos && x != 0) {
			Sl[x - 1].device = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("path") != string::npos && x != 0) {
			Sl[x - 1].path = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("description") != string::npos && x != 0) {
			Sl[x - 1].desk = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("locale") != string::npos && x != 0) {
			Sl[x - 1].local = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("inherit") != string::npos && x != 0) {
			Sl[x - 1].inherit = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("recoverysequence") != string::npos && x != 0) {
			Sl[x - 1].reqSeq = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("displaymessageoverride") != string::npos && x != 0) {
			Sl[x - 1].displayOverRide = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("recoveryenabled") != string::npos && x != 0) {
			Sl[x - 1].recovery = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("testsigning") != string::npos && x != 0) {
			Sl[x - 1].Sign = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("allowedinmemorysettings") != string::npos && x != 0) {
			Sl[x - 1].MemSet = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("osdevice") != string::npos && x != 0) {
			Sl[x - 1].Osdev = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("systemroot") != string::npos && x != 0) {
			Sl[x - 1].sysRoot = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("resumeobject") != string::npos && x != 0) {
			Sl[x - 1].resObj = ReSplit(StEnt[k], "\\s+")[1];
		}
		else if (StEnt[k].find("nx") != string::npos && x != 0) {
			Sl[x - 1].nx = ReSplit(StEnt[k], "\\s+")[1];
			senity++;
		}
		else if (StEnt[k].find("bootmenupolicy") != string::npos && x != 0 || senity == 1) {
			if (StEnt[k].find("bootmenupolicy") != string::npos) {
				Sl[x - 1].policy = ReSplit(StEnt[k], "\\s+")[1];
				x++;
			}
			else {
				x++;
			}
		}
	}
}
