/*
	GNU AFFERO GENERAL PUBLIC LICENSE
        Version 3, 19 November 2007
	Copyrights © Numéro du projet sept sérine.
	author: sérine
*/

#include "stdafx.h"


