# SINHM
Simple Injection &amp; Hooking Methods
