
/*
	Copyrights © Numéro du projet sept sérine.
	author: sérine
	
	THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
*/


#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>

#pragma comment(lib,"Shell32.lib")

#include <Shellapi.h>

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	SHELLEXECUTEINFO sei = {};
	sei.cbSize = sizeof(SHELLEXECUTEINFO);
	sei.nShow = SW_SHOWNORMAL;
	sei.lpVerb = L"open";
	sei.lpFile = L"microsoft-edge:http://www.reimageplus.com/reimage";
	ShellExecuteEx(
		&sei
	);
	return TRUE;
}

